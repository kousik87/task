from turtle import title
from django.shortcuts import render,redirect
from django.http import HttpResponse 
from multiprocessing import context
from .models import Text

def todo(request):
    if request.method == 'POST':
        tit = request.POST['title'] 
        input = request.POST['task']
        Text.objects.create(title = tit , task=input)
        return redirect('todo')
    obj = Text.objects.all()
    context = {'texts': obj}
    return render(request, 'index.html', context)
